import java.sql.*;
import java.util.Scanner;

public class LibrarySystem {
    private static Scanner sc = new Scanner(System.in);

    // ---------------- BOOK  ----------------
    public static void addBook() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            System.out.print("Title: "); String title = sc.nextLine();
            System.out.print("Author: "); String author = sc.nextLine();
            System.out.print("Category: "); String category = sc.nextLine();
            String availability = "";

System.out.println("Select Availability:");
System.out.println("1. Available");
System.out.println("2. Unavailable");
System.out.print("Choice: ");
String choice = sc.nextLine();

switch (choice) {
    case "1":
        availability = "Available";
        break;
    case "2":
        availability = "Unavailable";
        break;
    default:
        System.out.println("Invalid choice. Defaulting to Available.");
        availability = "Available";
}

            String sql = "INSERT INTO Books (Title, Author, Category, Availability) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, title);
            ps.setString(2, author);
            ps.setString(3, category);
            ps.setString(4, availability);
            ps.executeUpdate();
            System.out.println("Book added successfully.");
        } catch (SQLException e) { System.out.println(e.getMessage()); }
    }

    public static void viewBooks() {
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Books")) {
            while (rs.next()) {
                System.out.println(rs.getInt("BookID") + " | " + rs.getString("Title") + " | " +
                        rs.getString("Author") + " | " + rs.getString("Category") + " | " +
                        rs.getString("Availability"));
            }
        } catch (SQLException e) { System.out.println(e.getMessage()); }
    }

    public static void searchBook() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            System.out.print("Enter title, author, or ID to search: ");
            String keyword = sc.nextLine();
            String sql = "SELECT * FROM Books WHERE Title LIKE ? OR Author LIKE ? OR BookID LIKE ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");
            ps.setString(3, "%" + keyword + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                System.out.println(rs.getInt("BookID") + " | " + rs.getString("Title") + " | " +
                        rs.getString("Author") + " | " + rs.getString("Category") + " | " +
                        rs.getString("Availability"));
            }
        } catch (SQLException e) { System.out.println(e.getMessage()); }
    }

    public static void updateBook() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            System.out.print("Enter Book ID to update: ");
            int id = Integer.parseInt(sc.nextLine());
            System.out.print("New Title: "); String title = sc.nextLine();
            System.out.print("New Category: "); String category = sc.nextLine();
            String availability = "";

System.out.println("Select New Availability:");
System.out.println("1. Available");
System.out.println("2. Unavailable");
System.out.print("Choice: ");
String choice = sc.nextLine();

switch (choice) {
    case "1":
        availability = "Available";
        break;
    case "2":
        availability = "Unavailable";
        break;
    default:
        System.out.println("Keeping previous value.");
        return;
}
            String sql = "UPDATE Books SET Title=?, Category=?, Availability=? WHERE BookID=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, title);
            ps.setString(2, category);
            ps.setString(3, availability);
            ps.setInt(4, id);
            int rows = ps.executeUpdate();
            System.out.println(rows > 0 ? "Book updated." : "Book not found.");
        } catch (SQLException e) { System.out.println(e.getMessage()); }
    }

    public static void deleteBook() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            System.out.print("Enter Book ID to delete: ");
            int id = Integer.parseInt(sc.nextLine());
            System.out.print("Confirm delete (y/n): ");
            if (!sc.nextLine().equalsIgnoreCase("y")) return;
            String sql = "DELETE FROM Books WHERE BookID=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            int rows = ps.executeUpdate();
            System.out.println(rows > 0 ? "Book deleted." : "Book not found.");
        } catch (SQLException e) { System.out.println(e.getMessage()); }
    }

    // ---------------- MEMBER  ----------------
    public static void addMember() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            System.out.print("Name: "); String name = sc.nextLine();
            System.out.print("Email: "); String email = sc.nextLine();
            String type = "";

System.out.println("Select Membership Type:");
System.out.println("1. Gold Membership");
System.out.println("2. Silver Membership");
System.out.println("3. Bronze Membership");
System.out.print("Choice: ");
String choice = sc.nextLine();

switch (choice) {
    case "1":
        type = "Gold Membership";
        break;
    case "2":
        type = "Silver Membership";
        break;
    case "3":
        type = "Bronze Membership";
        break;
    default:
        System.out.println("Invalid choice. Defaulting to Bronze Membership.");
        type = "Bronze Membership";
}
            String sql = "INSERT INTO Members (Name, Email, MembershipType) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, type);
            ps.executeUpdate();
            System.out.println("Member registered.");
        } catch (SQLException e) { System.out.println(e.getMessage()); }
    }

    public static void viewMembers() {
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Members")) {
            while (rs.next()) {
                System.out.println(rs.getInt("MemberID") + " | " + rs.getString("Name") + " | " +
                        rs.getString("Email") + " | " + rs.getString("MembershipType"));
            }
        } catch (SQLException e) { System.out.println(e.getMessage()); }
    }

    public static void searchMember() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            System.out.print("Enter name or ID to search: ");
            String keyword = sc.nextLine();
            String sql = "SELECT * FROM Members WHERE Name LIKE ? OR MemberID LIKE ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                System.out.println(rs.getInt("MemberID") + " | " + rs.getString("Name") + " | " +
                        rs.getString("Email") + " | " + rs.getString("MembershipType"));
            }
        } catch (SQLException e) { System.out.println(e.getMessage()); }
    }

    public static void updateMember() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            System.out.print("Enter Member ID to update: ");
            int id = Integer.parseInt(sc.nextLine());
            System.out.print("New Name: "); String name = sc.nextLine();
            System.out.print("New Email: "); String email = sc.nextLine();

            String type = "";

System.out.println("Select New Membership Type:");
System.out.println("1. Gold Membership");
System.out.println("2. Silver Membership");
System.out.println("3. Bronze Membership");
System.out.print("Choice: ");
String choice = sc.nextLine();

switch (choice) {
    case "1":
        type = "Gold Membership";
        break;
    case "2":
        type = "Silver Membership";
        break;
    case "3":
        type = "Bronze Membership";
        break;
    default:
        System.out.println("Invalid choice. Keeping previous value.");
        return;
}

            String sql = "UPDATE Members SET Name=?, Email=?, MembershipType=? WHERE MemberID=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, type);
            ps.setInt(4, id);
            int rows = ps.executeUpdate();
            System.out.println(rows > 0 ? "Member updated." : "Member not found.");
        } catch (SQLException e) { System.out.println(e.getMessage()); }
    }

    public static void deleteMember() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            System.out.print("Enter Member ID to delete: ");
            int id = Integer.parseInt(sc.nextLine());
            System.out.print("Confirm delete (y/n): ");
            if (!sc.nextLine().equalsIgnoreCase("y")) return;
            String sql = "DELETE FROM Members WHERE MemberID=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            int rows = ps.executeUpdate();
            System.out.println(rows > 0 ? "Member deleted." : "Member not found.");
        } catch (SQLException e) { System.out.println(e.getMessage()); }
    }

    // ---------------- BORROWING ----------------
    public static void addBorrow() {
    try (Connection conn = DatabaseConnection.getConnection()) {

        System.out.print("Book ID: ");
        int bookID = Integer.parseInt(sc.nextLine());

        // CHECKING IF A BOOK IS AVAILABLE
        String checkSql = "SELECT Availability FROM Books WHERE BookID=?";
        PreparedStatement checkPs = conn.prepareStatement(checkSql);
        checkPs.setInt(1, bookID);
        ResultSet rs = checkPs.executeQuery();

        if (!rs.next()) {
            System.out.println("Book not found.");
            return;
        }

        String availability = rs.getString("Availability");

        if (!availability.equalsIgnoreCase("Available")) {
            System.out.println("Cannot borrow this book. It is currently unavailable.");
            return;
        }

        System.out.print("Member ID: ");
        int memberID = Integer.parseInt(sc.nextLine());

        System.out.print("Borrow Date (YYYY-MM-DD): ");
        String borrowDate = sc.nextLine();

        System.out.print("Due Date (YYYY-MM-DD): ");
        String dueDate = sc.nextLine();






        String sql = "INSERT INTO Borrowing (BookID, MemberID, BorrowDate, DueDate, Status) VALUES (?, ?, ?, ?, 'Borrowed')";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, bookID);
        ps.setInt(2, memberID);
        ps.setString(3, borrowDate);
        ps.setString(4, dueDate);
        ps.executeUpdate();





        String updateSql = "UPDATE Books SET Availability='Unavailable' WHERE BookID=?";
        PreparedStatement updatePs = conn.prepareStatement(updateSql);
        updatePs.setInt(1, bookID);
        updatePs.executeUpdate();

        System.out.println("Borrow record added.");

    } catch (SQLException e) {
        System.out.println(e.getMessage());
    }
}

    public static void viewBorrowings() {
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Borrowing")) {
            while (rs.next()) {
                System.out.println(rs.getInt("BorrowID") + " | Book " + rs.getInt("BookID") + " | Member " +
                        rs.getInt("MemberID") + " | " + rs.getString("BorrowDate") + " | " +
                        rs.getString("DueDate") + " | " + rs.getString("Status"));
            }
        } catch (SQLException e) { System.out.println(e.getMessage()); }
    }

    public static void searchBorrowing() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            System.out.print("Enter MemberID or BookID to search: ");
            String keyword = sc.nextLine();
            String sql = "SELECT * FROM Borrowing WHERE MemberID LIKE ? OR BookID LIKE ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                System.out.println(rs.getInt("BorrowID") + " | Book " + rs.getInt("BookID") + " | Member " +
                        rs.getInt("MemberID") + " | " + rs.getString("BorrowDate") + " | " +
                        rs.getString("DueDate") + " | " + rs.getString("Status"));
            }
        } catch (SQLException e) { System.out.println(e.getMessage()); }
    }

    public static void updateBorrowingStatus() {
    try (Connection conn = DatabaseConnection.getConnection()) {

        System.out.print("Enter Borrow ID to update status: ");
        int id = Integer.parseInt(sc.nextLine());


        String bookSql = "SELECT BookID FROM Borrowing WHERE BorrowID=?";
        PreparedStatement bookPs = conn.prepareStatement(bookSql);
        bookPs.setInt(1, id);
        ResultSet rs = bookPs.executeQuery();

        if (!rs.next()) {
            System.out.println("Borrow record not found.");
            return;
        }

        int bookID = rs.getInt("BookID");

        // STATUSS
        String status = "";

        System.out.println("Select New Status:");
        System.out.println("1. Borrowed");
        System.out.println("2. Returned");
        System.out.println("3. Overdue");
        System.out.print("Choice: ");
        String choice = sc.nextLine();

        switch (choice) {
            case "1":
                status = "Borrowed";
                break;
            case "2":
                status = "Returned";
                break;
            case "3":
                status = "Overdue";
                break;
            default:
                System.out.println("Invalid choice. No changes made.");
                return;
        }

        // UPDATE BORROW STATUS
        String sql = "UPDATE Borrowing SET Status=? WHERE BorrowID=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, status);
        ps.setInt(2, id);
        ps.executeUpdate();

        // IF BOOK RETURNED THIS MAKE THE BOOK AVAILABLE AGAIN
        if (status.equalsIgnoreCase("Returned")) {
            String updateBook = "UPDATE Books SET Availability='Available' WHERE BookID=?";
            PreparedStatement updatePs = conn.prepareStatement(updateBook);
            updatePs.setInt(1, bookID);
            updatePs.executeUpdate();
        }

        System.out.println("Status updated.");

    } catch (SQLException e) {
        System.out.println(e.getMessage());
    }
}

    public static void deleteBorrowRecord() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            System.out.print("Enter Borrow ID to delete: ");
            int id = Integer.parseInt(sc.nextLine());
            System.out.print("Confirm delete (y/n): ");
            if (!sc.nextLine().equalsIgnoreCase("y")) return;
            String sql = "DELETE FROM Borrowing WHERE BorrowID=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            int rows = ps.executeUpdate();
            System.out.println(rows > 0 ? "Borrow record deleted." : "Record not found.");
        } catch (SQLException e) { System.out.println(e.getMessage()); }
    }
}

