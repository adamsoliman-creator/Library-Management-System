import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection {
    private static final String URL = "jdbc:sqlite:library.db";

    public static Connection getConnection() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(URL);
        } catch (SQLException e) {
            System.out.println("Database connection error: " + e.getMessage());
        }
        return conn;
    }

    public static void initializeDatabase() {
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
            // Books table
            stmt.execute("CREATE TABLE IF NOT EXISTS Books (" +
                    "BookID INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "Title TEXT NOT NULL," +
                    "Author TEXT NOT NULL," +
                    "Category TEXT NOT NULL," +
                    "Availability TEXT NOT NULL)");

            // Members table
            stmt.execute("CREATE TABLE IF NOT EXISTS Members (" +
                    "MemberID INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "Name TEXT NOT NULL," +
                    "Email TEXT NOT NULL," +
                    "MembershipType TEXT NOT NULL)");

            // Borrow table
            stmt.execute("CREATE TABLE IF NOT EXISTS Borrowing (" +
                    "BorrowID INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "BookID INTEGER," +
                    "MemberID INTEGER," +
                    "BorrowDate TEXT," +
                    "DueDate TEXT," +
                    "Status TEXT," +
                    "FOREIGN KEY(BookID) REFERENCES Books(BookID)," +
                    "FOREIGN KEY(MemberID) REFERENCES Members(MemberID))");

        } catch (SQLException e) {
            System.out.println("Error initializing database: " + e.getMessage());
        }
    }
}
