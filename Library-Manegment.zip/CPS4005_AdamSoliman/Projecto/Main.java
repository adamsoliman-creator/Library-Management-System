import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        DatabaseConnection.initializeDatabase();
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n-------------------------------- LIBRARY MANAGEMENT SYSTEM --------------------------------");
            System.out.println("1. Manage Books");
            System.out.println("2. Manage Members");
            System.out.println("3. Manage Borrowing Records");
            System.out.println("4. Search Records");
            System.out.println("5. Exit");
            System.out.print("Choose option: ");
            String choice = sc.nextLine();

            switch (choice) {
                case "1":
                    manageBooks();
                    break;
                case "2":
                    manageMembers();
                    break;
                case "3":
                    manageBorrowings();
                    break;
                case "4":
                    searchRecords();
                    break;
                case "5":
                    System.out.println("Exiting System...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static void manageBooks() {
        Scanner sc = new Scanner(System.in);
        System.out.println("\n--- MANAGE BOOKS ---");
        System.out.println("1. Add Book");
        System.out.println("2. View Books");
        System.out.println("3. Update Book");
        System.out.println("4. Delete Book");
        System.out.println("5. Back");
        System.out.print("Choice: ");
        String c = sc.nextLine();
        switch (c) {
            case "1": LibrarySystem.addBook(); break;
            case "2": LibrarySystem.viewBooks(); break;
            case "3": LibrarySystem.updateBook(); break;
            case "4": LibrarySystem.deleteBook(); break;
        }
    }

    private static void manageMembers() {
        Scanner sc = new Scanner(System.in);
        System.out.println("\n--- MANAGE MEMBERS ---");
        System.out.println("1. Add Member");
        System.out.println("2. View Members");
        System.out.println("3. Update Member");
        System.out.println("4. Delete Member");
        System.out.println("5. Back");
        System.out.print("Choice: ");
        String c = sc.nextLine();
        switch (c) {
            case "1": LibrarySystem.addMember(); break;
            case "2": LibrarySystem.viewMembers(); break;
            case "3": LibrarySystem.updateMember(); break;
            case "4": LibrarySystem.deleteMember(); break;
        }
    }

    private static void manageBorrowings() {
        Scanner sc = new Scanner(System.in);
        System.out.println("\n--- MANAGE BORROWINGS ---");
        System.out.println("1. Add Borrow Record");
        System.out.println("2. View Borrow Records");
        System.out.println("3. Update Status");
        System.out.println("4. Delete Borrow Record");
        System.out.println("5. Back");
        System.out.print("Choice: ");
        String c = sc.nextLine();
        switch (c) {
            case "1": LibrarySystem.addBorrow(); break;
            case "2": LibrarySystem.viewBorrowings(); break;
            case "3": LibrarySystem.updateBorrowingStatus(); break;
            case "4": LibrarySystem.deleteBorrowRecord(); break;
        }
    }

    private static void searchRecords() {
        Scanner sc = new Scanner(System.in);
        System.out.println("\n--- SEARCH ---");
        System.out.println("1. Search Books");
        System.out.println("2. Search Members");
        System.out.println("3. Search Borrowings");
        System.out.print("Choice: ");
        String c = sc.nextLine();
        switch (c) {
            case "1": LibrarySystem.searchBook(); break;
            case "2": LibrarySystem.searchMember(); break;
            case "3": LibrarySystem.searchBorrowing(); break;
        }
    }
}
